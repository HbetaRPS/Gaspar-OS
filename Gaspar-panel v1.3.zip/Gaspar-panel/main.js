
/*
GASPAR OS
Windows Python launcher with integrated script editor.
*/

// === IMPORTS ===
const {
  Plugin,
  ItemView,
  Notice,
  MarkdownView,
  TFile,
  setIcon
} = require("obsidian");

const childProcess = require("child_process");
const path = require("path");
const process = require("process");

// === CONFIGURATION ===
const VIEW_TYPE = "python-panel-view";

const DEFAULT_SETTINGS = {
  scripts: [
    "software/python/obsidian-scripts/copy-focus-to-weekly.py",
    "software/python/obsidian-scripts/99clean.py",
    "software/python/obsidian-scripts/remove-empty-sections.py",
    "software/python/obsidian-scripts/remove-due-block.py",
    "software/python/obsidian-scripts/cleanup-latest-weekly.py"
  ]
};

const SELECTION_SCRIPT_NAMES = new Set([
  "reflow_prose_selection.py",
  "reflow-prose-selection.py"
]);

// === PROCESS HELPERS ===
function exec(command, options = {}) {
  return new Promise((resolve, reject) => {
    childProcess.exec(command, options, (error, stdout, stderr) => {
      if (error) {
        error.stdout = String(stdout || "");
        error.stderr = String(stderr || "");
        reject(error);
        return;
      }

      resolve({
        stdout: String(stdout || ""),
        stderr: String(stderr || "")
      });
    });
  });
}

function processEnv() {
  return { ...process.env };
}

function scriptTimeoutMs(scriptPath) {
  const name = path.basename(scriptPath);

  if (/^outlook_(export|unread_list|mark_unread)/i.test(name)) {
    return 45 * 60 * 1000;
  }

  return 60 * 1000;
}

function doneSummaryLine(stdout) {
  const lines = String(stdout || "")
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);

  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].startsWith("Done.")) {
      return lines[i].replace(/^Done\.\s*/, "");
    }
  }

  return null;
}

function isSeparator(entry) {
  return String(entry).startsWith("---");
}

function parseSeparator(entry) {
  const label = String(entry).slice(3).trim();
  return { label: label || null };
}

// === WINDOWS FILE PICKER ===
async function choosePythonFile() {
  if (process.platform !== "win32") {
    throw new Error("The Windows file picker is available only on Windows.");
  }

  /*
  Encode the PowerShell script as UTF-16LE Base64.
  This avoids most command-line quoting problems with Windows paths.
  */
  const psScript = [
    "Add-Type -AssemblyName System.Windows.Forms",
    "$dialog = New-Object System.Windows.Forms.OpenFileDialog",
    "$dialog.Title = 'Select a Python script for GASPAR OS'",
    "$dialog.Filter = 'Python files (*.py)|*.py|All files (*.*)|*.*'",
    "$dialog.Multiselect = $false",
    "$dialog.CheckFileExists = $true",
    "try {",
    "  if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {",
    "    [Console]::WriteLine($dialog.FileName)",
    "  }",
    "} finally {",
    "  $dialog.Dispose()",
    "}"
  ].join("\r\n");

  const encoded = Buffer
    .from(psScript, "utf16le")
    .toString("base64");

  const { stdout } = await exec(
    `powershell.exe -NoProfile -STA -EncodedCommand ${encoded}`,
    {
      windowsHide: true,
      timeout: 120000,
      maxBuffer: 1024 * 1024,
      env: processEnv()
    }
  );

  const selectedPath = stdout.trim();

  // An empty result means the user cancelled the dialog.
  if (!selectedPath) {
    return null;
  }

  if (!selectedPath.toLowerCase().endsWith(".py")) {
    throw new Error("Please select a .py file.");
  }

  return path.resolve(selectedPath);
}

// === SIDEBAR VIEW ===
class PythonPanelView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.runningScripts = new Set();
    this.editorOpen = false;
  }

  getViewType() {
    return VIEW_TYPE;
  }

  getDisplayText() {
    return "Gaspar OS";
  }

  getIcon() {
    return "settings";
  }

  async refresh() {
    await this.onOpen();
  }

  async onOpen() {
    const container = this.containerEl.children[1];

    container.empty();
    container.addClass("python-panel-container");

    const header = container.createDiv("gaspar-header");
    header.createEl("h2", { text: "Gaspar OS" });

    const scriptsContainer = container.createDiv("gaspar-script-list");

    for (const scriptPath of this.plugin.settings.scripts) {
      if (!String(scriptPath).trim()) continue;

      if (isSeparator(scriptPath)) {
        this.createSeparator(scriptsContainer, scriptPath);
      } else {
        this.createScriptButton(scriptsContainer, scriptPath);
      }
    }

    this.statusEl = container.createDiv("python-panel-status");

    // === GEAR BUTTON ===
    const settingsContainer = container.createDiv("gaspar-settings");

    const settingsButton = settingsContainer.createEl("button", {
      cls: "gaspar-settings-toggle",
      attr: {
        title: "Open script editor",
        "aria-label": "Open script editor",
        "aria-expanded": "false"
      }
    });

    const gearIcon = settingsButton.createSpan({
      cls: "gaspar-settings-icon"
    });

    setIcon(gearIcon, "settings");

    settingsButton.createSpan({
      text: "Settings",
      cls: "gaspar-settings-label"
    });

    const editor = settingsContainer.createDiv("gaspar-settings-editor");
    editor.style.display = this.editorOpen ? "block" : "none";

    settingsButton.setAttribute(
      "aria-expanded",
      String(this.editorOpen)
    );

    settingsButton.addEventListener("click", () => {
      this.editorOpen = !this.editorOpen;
      editor.style.display = this.editorOpen ? "block" : "none";

      settingsButton.setAttribute(
        "aria-expanded",
        String(this.editorOpen)
      );
    });

    this.renderEditor(editor);
  }

  renderEditor(editor) {
    editor.empty();

    editor.createEl("hr");

    editor.createEl("h3", {
      text: "Script Editor"
    });

    editor.createEl("p", {
      text: "Choose Python files from Windows or edit paths manually.",
      cls: "gaspar-settings-description"
    });

    // === FILE PICKER ===
    const pickerSection = editor.createDiv("gaspar-picker-section");

    const selectedPathInput = pickerSection.createEl("input", {
      cls: "gaspar-script-input gaspar-selected-path",
      attr: {
        type: "text",
        placeholder: "Selected .py file path",
        "aria-label": "Selected Python file path"
      }
    });

    const pickerButtons = pickerSection.createDiv(
      "gaspar-picker-buttons"
    );

    const browseButton = pickerButtons.createEl("button", {
      cls: "gaspar-browse-button",
      text: "Open File Explorer"
    });

    browseButton.addEventListener("click", async () => {
      browseButton.disabled = true;

      try {
        const selectedPath = await choosePythonFile();

        if (selectedPath) {
          selectedPathInput.value = selectedPath;
          selectedPathInput.focus();
          new Notice("File selected. Click Save File Path to add it.");
        }
      } catch (error) {
        console.error("[GASPAR] File picker error:", error);
        new Notice(`Could not open file picker: ${error.message}`);
      } finally {
        browseButton.disabled = false;
      }
    });

    const savePathButton = pickerButtons.createEl("button", {
      cls: "gaspar-save-path-button",
      text: "Save File Path"
    });

    savePathButton.addEventListener("click", async () => {
      const selectedPath = selectedPathInput.value.trim();

      if (!selectedPath) {
        new Notice("Select a Python file or enter its path first.");
        return;
      }

      if (!selectedPath.toLowerCase().endsWith(".py")) {
        new Notice("The selected file must have a .py extension.");
        return;
      }

      const normalizedPath = path.normalize(selectedPath);

      if (this.plugin.settings.scripts.includes(normalizedPath)) {
        new Notice("This script is already in the list.");
        return;
      }

      this.plugin.settings.scripts.push(normalizedPath);

      await this.plugin.saveSettings();

      new Notice("Script path saved.");

      this.editorOpen = true;
      await this.refresh();
    });

    // === EXISTING SCRIPT PATHS ===
    editor.createEl("h4", {
      text: "Configured scripts"
    });

    const entries = editor.createDiv("gaspar-settings-entries");

    this.plugin.settings.scripts.forEach((scriptPath, index) => {
      const row = entries.createDiv("gaspar-settings-row");

      const input = row.createEl("input", {
        cls: "gaspar-script-input",
        attr: {
          type: "text",
          placeholder: "Script path or --- Section name",
          "aria-label": `Script path ${index + 1}`
        }
      });

      input.value = scriptPath;

      const saveButton = row.createEl("button", {
        text: "Save",
        cls: "gaspar-row-save-button",
        attr: { title: "Save this path" }
      });

      saveButton.addEventListener("click", async () => {
        const newPath = input.value.trim();

        if (newPath && !isSeparator(newPath) &&
            !newPath.toLowerCase().endsWith(".py")) {
          new Notice("Script paths must end in .py, or start with ---.");
          return;
        }

        const duplicate = this.plugin.settings.scripts.some(
          (item, otherIndex) =>
            otherIndex !== index &&
            item.trim() === newPath &&
            newPath !== ""
        );

        if (duplicate) {
          new Notice("This script is already in the list.");
          return;
        }

        this.plugin.settings.scripts[index] = newPath;
        await this.plugin.saveSettings();

        new Notice("Script path saved.");
        await this.refresh();
      });

      const browseRowButton = row.createEl("button", {
        cls: "gaspar-row-browse-button",
        attr: {
          title: "Choose a .py file",
          "aria-label": "Choose Python file"
        }
      });

      setIcon(browseRowButton, "folder-open");

      browseRowButton.addEventListener("click", async () => {
        try {
          const selectedPath = await choosePythonFile();

          if (selectedPath) {
            input.value = selectedPath;
            input.focus();
          }
        } catch (error) {
          console.error("[GASPAR] File picker error:", error);
          new Notice(`Could not select file: ${error.message}`);
        }
      });

      const removeButton = row.createEl("button", {
        text: "×",
        cls: "gaspar-remove-button",
        attr: {
          title: "Remove script",
          "aria-label": "Remove script"
        }
      });

      removeButton.addEventListener("click", async () => {
        this.plugin.settings.scripts.splice(index, 1);
        await this.plugin.saveSettings();

        this.editorOpen = true;
        await this.refresh();
      });
    });

    const addButton = editor.createEl("button", {
      text: "+ Add empty path",
      cls: "gaspar-add-button"
    });

    addButton.addEventListener("click", async () => {
      this.plugin.settings.scripts.push("");
      await this.plugin.saveSettings();

      this.editorOpen = true;
      await this.refresh();
    });
  }

  createScriptButton(container, scriptPath) {
    const button = container.createEl("button", {
      cls: "python-panel-button",
      text: this.getScriptName(scriptPath),
      attr: { title: scriptPath }
    });

    button.addEventListener("click", () => {
      void this.runScript(scriptPath, button);
    });
  }

  createSeparator(container, entry) {
    const { label } = parseSeparator(entry);

    if (label) {
      container.createEl("h4", {
        cls: "python-panel-separator-label",
        text: label
      });
    } else {
      container.createEl("hr", {
        cls: "python-panel-separator"
      });
    }
  }

  getScriptName(scriptPath) {
    const cleaned = String(scriptPath).trim();
    return path.basename(cleaned);
  }

  isSelectionScript(scriptPath) {
    return SELECTION_SCRIPT_NAMES.has(this.getScriptName(scriptPath));
  }

  resolveScriptPath(scriptPath) {
    const cleaned = String(scriptPath).trim();

    // Absolute Windows paths work as well as vault-relative paths.
    if (path.isAbsolute(cleaned) || /^[A-Za-z]:[\\/]/.test(cleaned)) {
      return path.resolve(cleaned);
    }

    return path.resolve(
      this.app.vault.adapter.basePath,
      cleaned
    );
  }

  async runSelectionScript(
    scriptPath,
    fullScriptPath,
    pythonCmd,
    vaultPath,
    activeFilePath
  ) {
    const view = this.app.workspace.getActiveViewOfType(MarkdownView);

    if (!view) {
      throw new Error("Open a Markdown note first.");
    }

    const selected = view.editor.getSelection();

    if (!selected.trim()) {
      throw new Error("Select text in the note, then click the script button.");
    }

    const pluginDir = path.join(
      vaultPath,
      this.app.vault.configDir,
      "plugins",
      "Gaspar-panel"
    );

    const fs = require("fs");
    fs.mkdirSync(pluginDir, { recursive: true });

    const selectionIn = path.join(pluginDir, "selection-in.txt");
    const selectionOut = path.join(pluginDir, "selection-out.txt");

    fs.writeFileSync(selectionIn, selected, "utf8");

    const env = {
      ...processEnv(),
      PYTHONIOENCODING: "utf-8",
      OBSIDIAN_SELECTION_IN: selectionIn,
      OBSIDIAN_SELECTION_OUT: selectionOut,
      ...(activeFilePath && {
        OBSIDIAN_ACTIVE_FILE: activeFilePath
      })
    };

    const { stdout, stderr } = await exec(
      `"${pythonCmd}" "${fullScriptPath}"`,
      {
        cwd: vaultPath,
        timeout: scriptTimeoutMs(scriptPath),
        maxBuffer: 10 * 1024 * 1024,
        env
      }
    );

    if (stderr.trim()) {
      console.warn(`[GASPAR] ${this.getScriptName(scriptPath)} warnings:`, stderr);
    }

    let result = "";

    try {
      result = fs.readFileSync(selectionOut, "utf8");
    } catch (error) {
      // Fall back to standard output.
    }

    if (!result.trim()) result = stdout;

    if (!result.trim()) {
      throw new Error("The script produced no output.");
    }

    view.editor.replaceSelection(result);
  }

  async runScript(scriptPath, button) {
    if (this.runningScripts.has(scriptPath)) return;

    this.runningScripts.add(scriptPath);
    button.addClass("running");
    button.setAttribute("disabled", "true");
    this.hideStatus();

    try {
      const pythonCmd = await this.findPython();
      const vaultPath = this.app.vault.adapter.basePath;
      const fullScriptPath = this.resolveScriptPath(scriptPath);

      const fs = require("fs");

      if (!fs.existsSync(fullScriptPath)) {
        throw new Error(`Script file not found: ${fullScriptPath}`);
      }

      const activeFile = this.app.workspace.getActiveFile();

      const activeFilePath = activeFile
        ? path.join(vaultPath, activeFile.path)
        : null;

      if (this.isSelectionScript(scriptPath)) {
        await this.runSelectionScript(
          scriptPath,
          fullScriptPath,
          pythonCmd,
          vaultPath,
          activeFilePath
        );
      } else {
        const env = {
          ...processEnv(),
          PYTHONIOENCODING: "utf-8",
          ...(activeFilePath && {
            OBSIDIAN_ACTIVE_FILE: activeFilePath
          })
        };

        const { stdout, stderr } = await exec(
          `"${pythonCmd}" "${fullScriptPath}"`,
          {
            cwd: path.dirname(fullScriptPath),
            timeout: scriptTimeoutMs(scriptPath),
            maxBuffer: 10 * 1024 * 1024,
            env
          }
        );

        if (stderr.trim()) {
          console.warn(
            `[GASPAR] ${this.getScriptName(scriptPath)} warnings:`,
            stderr
          );
        }

        const done = doneSummaryLine(stdout);

        new Notice(
          done
            ? `${this.getScriptName(scriptPath)} — ${done}`
            : `Script completed: ${this.getScriptName(scriptPath)}`,
          15000
        );
      }

      this.showStatus(
        "success",
        `Script completed: ${this.getScriptName(scriptPath)}`
      );
    } catch (error) {
      const ex = error;
      const stderr = typeof ex.stderr === "string" ? ex.stderr : "";

      const message = error instanceof Error
        ? error.message
        : String(error);

      console.error(`[GASPAR] Error running ${scriptPath}:`, error);

      if (stderr.trim()) {
        console.warn(`[GASPAR] stderr:`, stderr);
      }

      new Notice(
        `${this.getScriptName(scriptPath)} failed: ${message}`,
        15000
      );

      this.showStatus(
        "error",
        `${this.getScriptName(scriptPath)}: ${message}`
      );
    } finally {
      this.runningScripts.delete(scriptPath);
      button.removeClass("running");
      button.removeAttribute("disabled");
    }
  }

  async findPython() {
    const commands = ["py", "python", "python3"];

    for (const cmd of commands) {
      try {
        await exec(`"${cmd}" --version`, {
          timeout: 10000,
          env: {
            ...processEnv(),
            PYTHONIOENCODING: "utf-8"
          }
        });

        return cmd;
      } catch (error) {
        // Try the next command.
      }
    }

    throw new Error("Python not found. Check your Python installation.");
  }

  showStatus(type, message) {
    this.statusEl.textContent = message;
    this.statusEl.className = `python-panel-status ${type} visible`;
  }

  hideStatus() {
    if (this.statusEl) {
      this.statusEl.className = "python-panel-status";
    }
  }
}

// === DATE HELPERS ===
function isoWeekNumber(date) {
  const d = new Date(
    Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())
  );

  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);

  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));

  return Math.ceil(
    ((d.getTime() - yearStart.getTime()) / 864e5 + 1) / 7
  );
}

// === PLUGIN ===
module.exports = class PythonPanelPlugin extends Plugin {
  async onload() {
    await this.loadSettings();

    this.registerView(
      VIEW_TYPE,
      leaf => new PythonPanelView(leaf, this)
    );

    this.addRibbonIcon("calendar-clock", "Gaspar OS", () => {
      void this.activateView();
    });

    this.addCommand({
      id: "open-panel",
      name: "Open Gaspar OS sidebar",
      callback: () => void this.activateView()
    });

    this.addCommand({
      id: "open-latest-weekly-note",
      name: "Open latest weekly note",
      callback: () => void this.openLatestWeeklyNote()
    });

    this.app.workspace.onLayoutReady(() => {
      void this.activateView();
    });
  }

  async activateView() {
    const existing = this.app.workspace.getLeavesOfType(VIEW_TYPE);

    if (existing.length) {
      const leaf = existing[0];
      await this.app.workspace.revealLeaf(leaf);
      return;
    }

    const rightLeaf = this.app.workspace.getRightLeaf(false);

    if (!rightLeaf) {
      new Notice("Could not open the GASPAR sidebar.");
      return;
    }

    await rightLeaf.setViewState({
      type: VIEW_TYPE,
      active: true
    });

    await this.app.workspace.revealLeaf(rightLeaf);
  }

  async openLatestWeeklyNote() {
    const MAX_DAYS_BACK = 10 * 366;
    const today = new Date();

    for (let i = 0; i < MAX_DAYS_BACK; i++) {
      const d = new Date(
        today.getFullYear(),
        today.getMonth(),
        today.getDate() - i
      );

      const iso = [
        d.getFullYear(),
        String(d.getMonth() + 1).padStart(2, "0"),
        String(d.getDate()).padStart(2, "0")
      ].join("-");

      const week = String(isoWeekNumber(d)).padStart(2, "0");

      const file = this.app.vault.getAbstractFileByPath(
        `daily/${iso}-week-${week}.md`
      );

      if (file instanceof TFile) {
        const leaf = this.app.workspace.getLeaf(false);
        await leaf.openFile(file);
        return;
      }
    }

    new Notice("No weekly note was found.");
  }

  async loadSettings() {
    const data = await this.loadData();

    this.settings = Object.assign({}, DEFAULT_SETTINGS, data);

    if (!Array.isArray(this.settings.scripts)) {
      this.settings.scripts = [...DEFAULT_SETTINGS.scripts];
    }
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
};
